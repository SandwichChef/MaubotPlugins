from typing import Dict, Type, Optional
from io import BytesIO
import asyncio

from aiohttp import ClientResponseError

from PIL import Image
from mimetypes import guess_extension

from mautrix.util.config import BaseProxyConfig, ConfigUpdateHelper
from mautrix.types import MediaMessageEventContent, MessageType, ImageInfo

from maubot import Plugin, MessageEvent
from maubot.handlers import command


class HostBot(Plugin):

    async def _reupload(self, message: str) -> Optional[MediaMessageEventContent]:
        url = message
        self.log.info(f"Reuploading {url}")
        resp = await self.http.get(url)
        data = await resp.read()
        img = Image.open(BytesIO(data))
        width, height = img.size
        mimetype = Image.MIME[img.format]
        filename = f"{message}{guess_extension(mimetype)}"
        mxc = await self.client.upload_media(data, mimetype, filename=filename)
        return MediaMessageEventContent(msgtype=MessageType.IMAGE, body=filename, url=mxc,
                                        info=ImageInfo(mimetype=mimetype, size=len(data),
                                                       width=width, height=height))

    @command.new("gallanthost", help="Rehost an image")
    @command.argument("message", pass_raw=True)
    async def echo_handler(self, evt: MessageEvent, message: str) -> None:
        pic = await self._reupload(message)
        await evt.respond(pic)
